﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arduuino22
{
    public partial class Form1 : Form
    {
        SerialPort serialPort;
        bool puertoCerrado = false;
        private SoundPlayer soundPlayer;
        public Form1()
        {
            InitializeComponent();
            serialPort = new SerialPort();
            // serialPort.DataReceived += newSerialDataReceivedEventHandler(SerialDataReceivedHandler);
            serialPort.PortName = "COM3";// Cambia esto segun tu configuracion 
            serialPort.BaudRate = 9600;
            ///serialPort.Open();
            soundPlayer = new SoundPlayer("C:\\User\\miria\\OneDriver\\Escritorio\\2024 semestre2\\MECANICA\\gifs\\Emergency Siren Police wail 02.wav");


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (puertoCerrado == false)
            {
                conectar();
            }
            else
            {
                noConectado();
            }
        }
        private void conectar()
        {
            try
            {
                puertoCerrado = true;
                serialPort.Open();
                botonConectar.Text = "DESCONECTR";
                botonConectar.BackColor = Color.Black;
                serialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }
        private void noConectado()
        {
            try
            {
                puertoCerrado = false;
                serialPort.Close();
                botonConectar.Text = "CONECTAR";
                botonConectar.BackColor = Color.Blue;
                listBox1.Items.Clear();
                // temperatutaLabel.Text = "TEMPERATURA °C";
                humedadlabel.Text = "HUMEDAD %";
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }
        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            string data = serialPort.ReadLine();
            this.Invoke(new MethodInvoker(delegate

                {
                    string[] values = data.Split('\t');
                    if (values.Length == 1)
                    {
                        //temperaturaLabel.Text = Values[1];

                        /*if(values<= "30")
                         {
                        soundPlayer.PlayLooping();
                        pictureBox1.BackColor=
                        System.Drawing.Color.Red;
                        }*/
                        humedadlabel.Text = values[0];

                        //listBox1.Items.Add(values[1]+""+ values[0]9;
                        listBox1.Items.Add(values[0]);
                    }
                }));
        }
        private void label2_Click(object sender, EventArgs e)
        {
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

                    }



        }
        



    
    

