﻿namespace arduuino22
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.temperaturalabel = new System.Windows.Forms.Label();
            this.humedadlabel = new System.Windows.Forms.Label();
            this.botonConectar = new System.Windows.Forms.Button();
            this.botonSalir = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // temperaturalabel
            // 
            this.temperaturalabel.AutoSize = true;
            this.temperaturalabel.Location = new System.Drawing.Point(109, 180);
            this.temperaturalabel.Name = "temperaturalabel";
            this.temperaturalabel.Size = new System.Drawing.Size(103, 13);
            this.temperaturalabel.TabIndex = 0;
            this.temperaturalabel.Text = "TEMPERATURA *C";
            // 
            // humedadlabel
            // 
            this.humedadlabel.AutoSize = true;
            this.humedadlabel.Location = new System.Drawing.Point(119, 289);
            this.humedadlabel.Name = "humedadlabel";
            this.humedadlabel.Size = new System.Drawing.Size(70, 13);
            this.humedadlabel.TabIndex = 1;
            this.humedadlabel.Text = "HUMEDAD%";
            // 
            // botonConectar
            // 
            this.botonConectar.Location = new System.Drawing.Point(137, 358);
            this.botonConectar.Name = "botonConectar";
            this.botonConectar.Size = new System.Drawing.Size(75, 23);
            this.botonConectar.TabIndex = 2;
            this.botonConectar.Text = "Conectar";
            this.botonConectar.UseVisualStyleBackColor = true;
            this.botonConectar.Click += new System.EventHandler(this.button1_Click);
            // 
            // botonSalir
            // 
            this.botonSalir.Location = new System.Drawing.Point(541, 358);
            this.botonSalir.Name = "botonSalir";
            this.botonSalir.Size = new System.Drawing.Size(75, 23);
            this.botonSalir.TabIndex = 3;
            this.botonSalir.Text = "Salir";
            this.botonSalir.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(337, 86);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(349, 251);
            this.listBox1.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.botonSalir);
            this.Controls.Add(this.botonConectar);
            this.Controls.Add(this.humedadlabel);
            this.Controls.Add(this.temperaturalabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label temperaturalabel;
        private System.Windows.Forms.Label humedadlabel;
        private System.Windows.Forms.Button botonConectar;
        private System.Windows.Forms.Button botonSalir;
        private System.Windows.Forms.ListBox listBox1;
    }
}

