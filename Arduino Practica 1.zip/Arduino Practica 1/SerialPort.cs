﻿namespace Arduino_Practica_1
{
    internal class SerialPort : System.IO.Ports.SerialPort
    {
        public SerialPort(string portName, int baudRate) : base(portName, baudRate)
        {
        }
    }
}